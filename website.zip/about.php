<?php require_once('includes/header.php'); ?>

<div id="container-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center" color="black">Who are we?</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et 
                    dolore magna aliqua. Fames ac turpis egestas maecenas pharetra convallis posuere morbi leo. Odio aenean 
                    sed adipiscing diam. Hac habitasse platea dictumst quisque sagittis purus. Egestas purus viverra 
                    accumsan in nisl. Mattis ullamcorper velit sed ullamcorper morbi tincidunt ornare massa eget. Duis ut 
                    diam quam nulla porttitor massa id neque. Velit scelerisque in dictum non consectetur a erat nam. 
                    Imperdiet proin fermentum leo vel orci porta non pulvinar. Sit amet mattis vulputate enim nulla aliquet 
                    porttitor lacus luctus. Porta nibh venenatis cras sed felis eget velit aliquet. Aliquet porttitor lacus 
                    luctus accumsan tortor. Malesuada fames ac turpis egestas integer eget. Nisl rhoncus mattis rhoncus urna. 
                    Ridiculus mus mauris vitae ultricies leo. Ut porttitor leo a diam sollicitudin tempor. Nisi vitae 
                    suscipit tellus mauris a. Donec ac odio tempor orci dapibus ultrices. Dictum non consectetur a erat 
                    nam at lectus.
                </p>
            </div>
        </div>
    </div>
</div>

<div id="container-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center" color="black">What we offer</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et 
                    dolore magna aliqua. Fames ac turpis egestas maecenas pharetra convallis posuere morbi leo. Odio aenean 
                    sed adipiscing diam. Hac habitasse platea dictumst quisque sagittis purus. Egestas purus viverra 
                    accumsan in nisl. Mattis ullamcorper velit sed ullamcorper morbi tincidunt ornare massa eget. Duis ut 
                    diam quam nulla porttitor massa id neque. Velit scelerisque in dictum non consectetur a erat nam. 
                    Imperdiet proin fermentum leo vel orci porta non pulvinar. Sit amet mattis vulputate enim nulla aliquet 
                    porttitor lacus luctus. Porta nibh venenatis cras sed felis eget velit aliquet. Aliquet porttitor lacus 
                    luctus accumsan tortor. Malesuada fames ac turpis egestas integer eget. Nisl rhoncus mattis rhoncus urna. 
                    Ridiculus mus mauris vitae ultricies leo. Ut porttitor leo a diam sollicitudin tempor. Nisi vitae 
                    suscipit tellus mauris a. Donec ac odio tempor orci dapibus ultrices. Dictum non consectetur a erat 
                    nam at lectus.
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once('includes/footer.php'); ?>
