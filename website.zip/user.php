<?php 
require_once('includes/header.php'); 

if(!$user->is_logged_in()) {
    header('Location: login.php');
    exit;
}
?>

<div id="container-white">
</div>


<?php 
require_once('includes/footer.php'); 
?>
