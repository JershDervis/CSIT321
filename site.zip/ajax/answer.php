<?php
require_once($_SERVER['DOCUMENT_ROOT'] .'/config.php');

if(!$user->is_logged_in()) {
    header('Location: login.php');
    exit;
}

if(isset($_POST['answer'])) {
    $user->submitAnswer($_POST['answer']);
}

?>